package com.app.employeedetails;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.TextView;

public class DetailDataActivity extends AppCompatActivity {
    TextView name,age,salary;//define
    Toolbar toolbar1;//defining toolbar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_data);
        //initialization with address

        name=findViewById(R.id.txtname);
        age=findViewById(R.id.txtage);
        salary=findViewById(R.id.txtsalary);

        //toolbar for come to back
        toolbar1=findViewById(R.id.toolbarnews);
        setSupportActionBar(toolbar1);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        //getting data through intent from adapter class

        name.setText(getIntent().getExtras().getString("empName"));
        age.setText(getIntent().getExtras().getString("empAge"));
        salary.setText(getIntent().getExtras().getString("empSalary"));

    }

    //toolbar back to home
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==android.R.id.home){

            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}