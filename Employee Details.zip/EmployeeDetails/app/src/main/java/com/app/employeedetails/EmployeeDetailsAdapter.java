package com.app.employeedetails;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EmployeeDetailsAdapter extends RecyclerView.Adapter<EmployeeDetailsAdapter.ViewHolder>{

    Context context;
    List<EmployeeModel> emp_list;
    public EmployeeDetailsAdapter(Context context, List<EmployeeModel> emp_list) {
        this.context=context;
        this.emp_list=emp_list;
    }

    @NonNull
    @Override
    public EmployeeDetailsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item_design,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EmployeeDetailsAdapter.ViewHolder holder, int position) {

        holder.name.setText(emp_list.get(position).getName());
        holder.age.setText(emp_list.get(position).getAge());
        holder.salary.setText(emp_list.get(position).getSalary());

        //storing ech emp data in variables

        String e_name=emp_list.get(position).getName();
        String e_age=emp_list.get(position).getAge();
        String e_salary=emp_list.get(position).getSalary();


        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //transfer data with intent to next activity
                Intent intent = new Intent(v.getContext(), DetailDataActivity.class);
                intent.putExtra("empName",e_name);
                intent.putExtra("empAge",e_age);
                intent.putExtra("empSalary",e_salary);

                v.getContext().startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return emp_list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView name,age,salary;
        private LinearLayout linearLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            name=itemView.findViewById(R.id.nametxt);
            age=itemView.findViewById(R.id.agetxt);
            salary=itemView.findViewById(R.id.salarytxt);
            linearLayout=itemView.findViewById(R.id.linearlayout);
        }

    }
}
